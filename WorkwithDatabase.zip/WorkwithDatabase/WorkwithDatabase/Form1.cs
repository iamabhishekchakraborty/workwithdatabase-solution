﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Data.Sql;
using System.Web.Security;
//using System.Reflection;
using System.Runtime.CompilerServices;

namespace WorkwithDatabase
{
    public partial class Form1 : Form
    {
        private string userName = string.Empty;

        //static SqlConnection databaseConnection = null;
        
        public Form1()
        {
            InitializeComponent();            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //get the current logged in user's username(NTID)
                userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                /*
                DataTable dt = new DataTable();
                dt = DatabaseInterface.getData();

                BindingSource primaryGroupsBinding = new BindingSource();
                primaryGroupsBinding.DataSource = dt;
                dataGridView1.DataSource = primaryGroupsBinding;
                */
                //populate server names
                //string[] localServers = new string[] { "IGTEHYDZSDB01", "IGTEHYDZSDB02", ".\\SQLEXPRESS"};
                //comboBox1.Items.AddRange(localServers);
                
                DataTable dtServer = SqlDataSourceEnumerator.Instance.GetDataSources();
                List<string> server = new List<string>();
                BindingSource bs = new BindingSource();
                
                foreach (DataRow item in dtServer.Rows)
                {
                    server.Add(item["ServerName"].ToString());
                }
                bs.DataSource = server;
                comboBox1.DataSource = bs;
                
                
                //authentication process
                radioButton1.Checked = true;
                //radioButton2.Checked = false;
                textBox1.Text = userName;
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                comboBox1.Text = "Please select any server name from the list";
                comboBox2.Enabled = false;
                comboBox3.Enabled = false;
                comboBox4.Enabled = false;

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"Error!!!");
            }
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            comboBox2.Enabled = true;
            comboBox2.Text = "Please, select any database name";
        }

        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
            comboBox2.Enabled = true;
            comboBox2.Text = "Please, select any database name";
        }

        //Executed when any radio button is changed
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            foreach (Control control in this.groupBox4.Controls)
            {
                if (control is RadioButton)
                {
                    RadioButton radio = control as RadioButton;
                    if (radio.Checked)
                    {
                        if (radio.Text == "Use Sql Server Authentication")
                        {
                            //radioButton1.Checked = false;
                            //radioButton2.Checked = true;
                            textBox1.Clear();
                            textBox2.Clear();
                            //comboBox2.Items.Clear();
                            comboBox2.SelectedIndex = -1;
                            comboBox3.SelectedIndex = -1;
                            comboBox4.SelectedIndex = -1;
                            //comboBox2.Enabled = false;
                            textBox1.Enabled = true;
                            textBox2.Enabled = true;
                            textBox1.ReadOnly = false;
                            textBox2.ReadOnly = false;
                            comboBox3.Enabled = false;
                            comboBox4.Enabled = false;
                        }
                        else
                        {
                            textBox1.Clear();
                            textBox2.Clear();
                            textBox1.Enabled = false;
                            textBox2.Enabled = false;
                            //comboBox2.Items.Clear();
                            comboBox2.SelectedIndex = -1;
                            comboBox3.SelectedIndex = -1;
                            comboBox4.SelectedIndex = -1;
                            textBox1.Text = userName;
                            //comboBox2.Enabled = false;
                            //radioButton1.Checked = true;
                            //radioButton2.Checked = false;
                            comboBox3.Enabled = false;
                            comboBox4.Enabled = false;
                        }
                    }
                }
            }
            comboBox2.Text = "Please, select any database name";
        }

        private void GetDatabaseConnection([CallerMemberName] string callerName = "")
        {
            string serverName = string.Empty;
            string userId = string.Empty;
            string password = string.Empty;
            string connectionString = string.Empty;
            string sqlStatement = string.Empty;
            string selectedObjectType = string.Empty;
            string sqlStatementObjectName = string.Empty;
            string databaseName = string.Empty;

            //MessageBox.Show(callerName + "called me.");

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            BindingSource primaryGroupsBinding = new BindingSource();

            serverName = comboBox1.SelectedIndex == -1 ? comboBox1.Text : comboBox1.SelectedItem.ToString();
            databaseName = comboBox2.SelectedIndex == -1 ? "master" : comboBox2.GetItemText(comboBox2.SelectedItem);

            if (radioButton1.Checked == true)
            {
                connectionString = "Data Source=" + serverName + ";Initial Catalog=" + databaseName + ";Integrated Security=True;";
            }
            else
            {
                userId = textBox1.Text;
                password = textBox2.Text;
                connectionString = "Data Source=" + serverName + ";Initial Catalog=" + databaseName + ";User ID=" + userId + ";Password=" + password + ";";
            }

            using (SqlConnection databaseConnection = new SqlConnection())
            {
                databaseConnection.ConnectionString = connectionString;
                if (callerName == "comboBox2_Click")
                {
                    sqlStatement = "SELECT name FROM sys.sysdatabases WHERE HAS_DBACCESS(name) = 1";
                    
                    using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatement, databaseConnection))
                    {
                        myDatabaseAdapter.Fill(ds, "DatabaseNames");
                        dt = ds.Tables[0];
                        primaryGroupsBinding.DataSource = dt;
                        comboBox2.DisplayMember = "name";
                        comboBox2.DataSource = dt;
                    }
                }
                else if (callerName == "comboBox2_SelectionChangeCommitted")
                {
                    sqlStatement = "SELECT DISTINCT o.type_desc AS ObjectName,o.type AS ObjectType FROM sys.objects o INNER JOIN sys.schemas s ON o.schema_id = s.schema_id";
                    //upon changing the database list get object types and populate comboBox3
                    using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatement, databaseConnection))
                    {
                        myDatabaseAdapter.Fill(ds, "ObjectTypes");
                        dt = ds.Tables[0];
                        primaryGroupsBinding.DataSource = dt;
                        comboBox3.DisplayMember = "ObjectName";
                        comboBox3.ValueMember = "ObjectType";
                        comboBox3.DataSource = dt;
                    }
                    selectedObjectType = comboBox3.SelectedIndex == 0 ? comboBox3.Text : comboBox3.GetItemText(comboBox3.SelectedItem);
                    sqlStatementObjectName = "with objects_cte as ("
                               + "select o.name,o.type_desc,o.type,case when o.principal_id is null then s.principal_id else o.principal_id end as principal_id"
                               + " from sys.objects o inner join sys.schemas s on o.schema_id = s.schema_id"
                               + " and o.type_desc = '" + selectedObjectType + "')"
                               + " select cte.name as Name"
                               + " from objects_cte cte inner join sys.database_principals dp on cte.principal_id = dp.principal_id";
                             //+ " where dp.name = <logged in user name>";
                    //populate combo box Object Names
                    using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatementObjectName, databaseConnection))
                    {
                        myDatabaseAdapter.Fill(ds, "ObjectNames");
                        dt = ds.Tables[1];
                        primaryGroupsBinding.DataSource = dt;
                        comboBox4.DisplayMember = "Name";
                        comboBox4.DataSource = dt;
                    }

                }
                else if (callerName == "comboBox3_SelectionChangeCommitted")
                {
                    selectedObjectType = comboBox3.SelectedIndex == 0 ? comboBox3.Text : comboBox3.GetItemText(comboBox3.SelectedItem);
                    //populate combo box Object Names               
                    sqlStatementObjectName = "with objects_cte as ("
                               + "select o.name,o.type_desc,o.type,case when o.principal_id is null then s.principal_id else o.principal_id end as principal_id"
                               + " from sys.objects o inner join sys.schemas s on o.schema_id = s.schema_id"
                               + " and o.type_desc = '" + selectedObjectType + "')"
                               + " select cte.name as Name"
                               + " from objects_cte cte inner join sys.database_principals dp on cte.principal_id = dp.principal_id";
                    //+ " where dp.name = <logged in user name>";
                    using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatementObjectName, databaseConnection))
                    {
                        myDatabaseAdapter.Fill(ds, "ObjectNames");
                        dt = ds.Tables[0];
                        primaryGroupsBinding.DataSource = dt;
                        comboBox4.DisplayMember = "Name";
                        comboBox4.DataSource = dt;
                    }
                }
            }
        }

        //executed when database list is invoked - db connection and list of database will be displayed
        private void comboBox2_Click(object sender, EventArgs e)
        {
            /*
            //string serverName = comboBox1.GetItemText(comboBox1.SelectedItem);
            string serverName = comboBox1.SelectedIndex == -1 ? comboBox1.Text : comboBox1.SelectedItem.ToString();
            string userId;
            string password;
            string connectionString;

            if (radioButton1.Checked == true)
            {
                password = "";
                connectionString = "Data Source=" + serverName + ";Initial Catalog=master;Integrated Security=True;";
            }
            else
            {
                userId = textBox1.Text;
                password = textBox2.Text;
                connectionString = "Data Source=" + serverName + ";Initial Catalog=master;User ID=" + userId + ";Password=" + password + ";";
            }
            
            //make db connection
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            BindingSource primaryGroupsBinding = new BindingSource();
            string sqlStatement = "SELECT name FROM sys.sysdatabases WHERE HAS_DBACCESS(name) = 1";
            
            using (SqlConnection databaseConnection = new SqlConnection())
            {
                databaseConnection.ConnectionString = connectionString;
                using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatement, databaseConnection))
                {
                    myDatabaseAdapter.Fill(ds, "DatabaseNames");
                    dt = ds.Tables[0];
                    primaryGroupsBinding.DataSource = dt;
                    comboBox2.DisplayMember = "name";
                    comboBox2.DataSource = dt;
                }
            }
            */
            GetDatabaseConnection();

            //System.Threading.Thread.Sleep(500); //slepp for 500 milliseconds

            //MessageBox.Show(connectionString);                        
        }

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            /*
            string serverName = comboBox1.SelectedIndex == -1 ? comboBox1.Text : comboBox1.SelectedItem.ToString();
            string databaseName = comboBox2.GetItemText(comboBox2.SelectedItem);
            string userId;
            string password;
            string connectionString;

            if (radioButton1.Checked == true)
            {
                password = "";
                connectionString = "Data Source=" + serverName + ";Initial Catalog=" + databaseName + ";Integrated Security=True;";
            }
            else
            {
                userId = textBox1.Text;
                password = textBox2.Text;
                connectionString = "Data Source=" + serverName + ";Initial Catalog=" + databaseName + ";User ID=" + userId + ";Password=" + password + ";";
            }
            
            //make db connection
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            BindingSource primaryGroupsBinding = new BindingSource();
            string sqlStatementObjectType = "SELECT DISTINCT o.type_desc AS ObjectName,o.type AS ObjectType FROM sys.objects o INNER JOIN sys.schemas s ON o.schema_id = s.schema_id";
            string selectedObjectType = "";
            string sqlStatementObjectName = "";

            using (SqlConnection databaseConnection = new SqlConnection())
            {
                databaseConnection.ConnectionString = connectionString;
                //upon changing the database list get object types and populate comboBox3
                using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatementObjectType, databaseConnection))
                {
                    myDatabaseAdapter.Fill(ds, "ObjectTypes");
                    dt = ds.Tables[0];
                    primaryGroupsBinding.DataSource = dt;
                    comboBox3.DisplayMember = "ObjectName";
                    comboBox3.ValueMember = "ObjectType";
                    comboBox3.DataSource = dt;
                }

                //System.Threading.Thread.Sleep(500);

                selectedObjectType = comboBox3.GetItemText(comboBox3.SelectedItem);
                sqlStatementObjectName = "with objects_cte as ("
                                           + "select o.name,o.type_desc,o.type,case when o.principal_id is null then s.principal_id else o.principal_id end as principal_id"
                                           + " from sys.objects o inner join sys.schemas s on o.schema_id = s.schema_id"
                                           + " and o.type_desc = '" + selectedObjectType + "')"
                                           + " select cte.name as Name"
                                           + " from objects_cte cte inner join sys.database_principals dp on cte.principal_id = dp.principal_id";
                //+ " where dp.name = <logged in user name>";

                //populate combo box Object Names
                using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatementObjectName, databaseConnection))
                {
                    myDatabaseAdapter.Fill(ds, "ObjectNames");
                    dt = ds.Tables[1];
                    primaryGroupsBinding.DataSource = dt;
                    comboBox4.DisplayMember = "Name";
                    comboBox4.DataSource = dt;
                }
            }
             */

            GetDatabaseConnection();
            comboBox3.Enabled = true;
            comboBox4.Enabled = true;
        }

        //Executed when any combo box is selection is changed - group box 3
        private void comboBox3_SelectionChangeCommitted(object sender, EventArgs e)
        {
            /*
            string serverName = comboBox1.SelectedIndex == -1 ? comboBox1.Text : comboBox1.SelectedItem.ToString();
            string databaseName = comboBox2.GetItemText(comboBox2.SelectedItem);
            string selectedObjectType = comboBox3.GetItemText(comboBox3.SelectedItem);
            string sqlStatementObjectName = string.Empty;
            string userId;
            string password;
            string connectionString;

            var cb = ((ComboBox)sender);
            string comboName = (string)cb.Name.ToString();

            if (comboName == "comboBox3")
            {
                if (radioButton1.Checked == true)
                {
                    password = "";
                    connectionString = "Data Source=" + serverName + ";Initial Catalog=" + databaseName + ";Integrated Security=True;";
                }
                else
                {
                    userId = textBox1.Text;
                    password = textBox2.Text;
                    connectionString = "Data Source=" + serverName + ";Initial Catalog=" + databaseName + ";User ID=" + userId + ";Password=" + password + ";";
                }
                //make db connection
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                BindingSource primaryGroupsBinding = new BindingSource();
  
                using (SqlConnection databaseConnection = new SqlConnection())
                {
                    databaseConnection.ConnectionString = connectionString;                 
                    //populate combo box Object Names               
                    sqlStatementObjectName = "with objects_cte as ("
                                               + "select o.name,o.type_desc,o.type,case when o.principal_id is null then s.principal_id else o.principal_id end as principal_id"
                                               + " from sys.objects o inner join sys.schemas s on o.schema_id = s.schema_id"
                                               + " and o.type_desc = '" + selectedObjectType + "')"
                                               + " select cte.name as Name"
                                               + " from objects_cte cte inner join sys.database_principals dp on cte.principal_id = dp.principal_id";
                    //+ " where dp.name = <logged in user name>";
                    using (SqlDataAdapter myDatabaseAdapter = new SqlDataAdapter(sqlStatementObjectName, databaseConnection))
                    {
                        myDatabaseAdapter.Fill(ds, "ObjectNames");
                        dt = ds.Tables[0];
                        primaryGroupsBinding.DataSource = dt;
                        comboBox4.DisplayMember = "Name";
                        comboBox4.DataSource = dt;
                    }
                }
            }
             */
            GetDatabaseConnection();
            comboBox4.Enabled = true;
        }
    }
}
